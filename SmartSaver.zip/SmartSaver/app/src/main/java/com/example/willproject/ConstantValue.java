package com.example.willproject;

public class ConstantValue {

   public static float rent;
    public static float food;
    public static float utility;
    public static float save;
    public static float tax;
    public static float retire;
    public static float insurance;


}
