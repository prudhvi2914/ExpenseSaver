package com.example.willproject;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.chart.common.listener.Event;
import com.anychart.chart.common.listener.ListenersInterface;
import com.anychart.charts.Pie;
import com.anychart.enums.Align;
import com.anychart.enums.LegendLayout;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.PieChartView;

public class MapActivtiy extends FragmentActivity implements OnMapReadyCallback {

    Button button;
    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    public static final int REQUEST_CODE = 101;

    NearByConsultants nearByConsultants;

    double letValueMain;
    double longValueMain;


    private static String TAG = "MainActivity";
    //
    private float[] yData = {25.3f, 10.6f, 66.76f, 44.32f, 46.01f, 16.89f, 23.9f};
    private String[] xData = {"Rent", "Jessica", "Mohammad", "Kelsey", "Sam", "Robert", "Ashley"};
    AnyChartView pieChart;

    //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_activtiy);

        button = findViewById(R.id.show);
        button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(MapActivtiy.this);
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    Activity#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for Activity#requestPermissions for more details.
                    return;
                }
               /* Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                longValueMain = location.getLongitude();
                Log.d("tag", "ontry:" +longValueMain);
                letValueMain = location.getLatitude();
                Log.d("tag", "ontry:" +letValueMain);*/

                Intent intent = new Intent(MapActivtiy.this,NearByConsultants.class);
                intent.putExtra("latitude", letValueMain);
                intent.putExtra("longitude", longValueMain);
                startActivity(intent);


            }
        });

        //----------------------------------------
        Log.d(TAG, "onCreate: starting to create chart");

        pieChart =  findViewById(R.id.idPieChart);
      /*  List<SliceValue> values = new ArrayList<SliceValue>();
        SliceValue sliceValue = new SliceValue((float) ConstantValue.rent, getResources().getColor(R.color.colorone));
        values.add(sliceValue);
        SliceValue sliceValue1 = new SliceValue((float)ConstantValue.food, getResources().getColor(R.color.colortwo));
        values.add(sliceValue1);
        SliceValue sliceValue2 = new SliceValue((float)ConstantValue.utility, getResources().getColor(R.color.colorthree));
        values.add(sliceValue2);
        SliceValue sliceValue3 = new SliceValue((float)ConstantValue.save, getResources().getColor(R.color.colorfour));
        values.add(sliceValue3);
        SliceValue sliceValue4 = new SliceValue((float)ConstantValue.tax, getResources().getColor(R.color.colorfive));
        values.add(sliceValue4);
        SliceValue sliceValue5 = new SliceValue((float)ConstantValue.retire, getResources().getColor(R.color.colorsix));
        values.add(sliceValue5);
        SliceValue sliceValue6 = new SliceValue((float)ConstantValue.insurance, getResources().getColor(R.color.colorseven));
        values.add(sliceValue6);

        PieChartData data = new PieChartData(values);
        data.setHasLabels(true);
        data.setHasLabelsOutside(false);
        data.setSlicesSpacing(1);

        pieChart.setPieChartData(data);*/
      //  pieChart.setDescription("Sales by employee (In Thousands $) ");

        Pie pie = AnyChart.pie();

        pie.setOnClickListener(new ListenersInterface.OnClickListener(new String[]{"x", "value"}) {
            @Override
            public void onClick(Event event) {
                Toast.makeText(MapActivtiy.this, event.getData().get("x") + ":" + event.getData().get("value"), Toast.LENGTH_SHORT).show();
            }
        });
        List<DataEntry> data = new ArrayList<>();
        data.add(new ValueDataEntry("Rent",(int)(ConstantValue.rent)));
        data.add(new ValueDataEntry("food", (int)ConstantValue.food));
        data.add(new ValueDataEntry("utility", (int)ConstantValue.utility));
        data.add(new ValueDataEntry("save", (int)ConstantValue.save));
        data.add(new ValueDataEntry("tax", (int)ConstantValue.tax));
        data.add(new ValueDataEntry("retire", (int)ConstantValue.retire));
        data.add(new ValueDataEntry("insurance", (int)ConstantValue.insurance));

        Log.d(TAG, "onCreate: "+(int)ConstantValue.rent +":"+(int)ConstantValue.food+":"+(int)ConstantValue.insurance);

        pie.data(data);

        pie.title("BreakDown");

        pie.legend()
                .position("center-bottom")
                .itemsLayout(LegendLayout.HORIZONTAL)
                .align(Align.CENTER);
        pie.labels().position("outside");
        pie.legend().title().enabled(true);
        pie.legend().title()
                .text("Retail channels")
                .padding(0d, 0d, 10d, 0d);

        pie.legend()
                .position("center-bottom")
                .itemsLayout(LegendLayout.HORIZONTAL)
                .align(Align.CENTER);
        pieChart.setChart(pie);
       /* pieChart.setRotationEnabled(true);

        pieChart.setHoleRadius(25f);
        pieChart.setTransparentCircleAlpha(0);
        pieChart.setCenterText("BreakDown");
        pieChart.setCenterTextSize(10);*/


      //  addDataSet();
/*
///ONclickListerner
        pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                Log.d(TAG, "onValueSelected: Value select from chart.");
                Log.d(TAG, "onValueSelected: " + e.toString());
                Log.d(TAG, "onValueSelected: " + h.toString());
//getting the e/entry value
                int pos1 = e.toString().indexOf("(sum): ");
                String sales = e.toString().substring(pos1 + 7);
//
//                for(int i = 0; i < yData.length; i++){
//                    if(yData[i] == Float.parseFloat(sales)){
//                        pos1 = i;
//                        break;
//                    }
//                }
//                String employee = xData[pos1 + 1];
//                Toast.makeText(MapActivtiy.this, "Employee " + employee + "\n" + "Sales: $" + sales + "K", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected() {

            }
        });

*/


//----------------------------------------

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLastLocation();
    }

    private void fetchLastLocation() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);

return;
        }

        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location != null){

                    currentLocation = location;
                    longValueMain=currentLocation.getLongitude();
                    letValueMain=currentLocation.getLatitude();
                    Toast.makeText(getApplicationContext(),currentLocation.getLatitude()+""+currentLocation.getLongitude(),Toast.LENGTH_LONG).show();
                    SupportMapFragment supportMapFragment = (SupportMapFragment)
                            getSupportFragmentManager().findFragmentById(R.id.google_map);
                    supportMapFragment.getMapAsync(MapActivtiy.this);

                }
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng latLng = new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("I am Here");
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,5));
        googleMap.addMarker(markerOptions);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){

            case REQUEST_CODE:
                if(grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                fetchLastLocation();

                }
                 break;

        }
    }

  /*  private void addDataSet() {
        Log.d(TAG, "addDataSet started");
        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();

        for(int i = 0; i < yData.length; i++){
            yEntrys.add(new PieEntry(yData[i] , i));
        }

        for(int i = 1; i < xData.length; i++){
            xEntrys.add(xData[i]);
        }

        //create the data set
        PieDataSet pieDataSet = new PieDataSet(yEntrys, "ExpenseBreakdown");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(20);

        //add colors to dataset
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.GRAY);
        colors.add(Color.BLUE);
        colors.add(Color.RED);
        colors.add(Color.GREEN);
        colors.add(Color.CYAN);
        colors.add(Color.YELLOW);
        colors.add(Color.MAGENTA);

        pieDataSet.setColors(colors);

        //add legend to chart
       // Legend legend = pieChart.getLegend();
       // legend.setForm(Legend.LegendForm.CIRCLE);
        //legend.setPostion(Legend.LegendPosition.LEFT_OF_CHART);


        //create pie data object
        PieData pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieChart.invalidate();
    }
*/

}


